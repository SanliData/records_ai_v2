def detect(context: dict):
    """Passive detection hook."""
    return True
