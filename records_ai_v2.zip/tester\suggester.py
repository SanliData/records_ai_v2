def suggest(error: Exception, context: dict) -> list:
    return [
        "Inspect schema validation",
        "Check pipeline contracts",
        "Review recent changes"
    ]
