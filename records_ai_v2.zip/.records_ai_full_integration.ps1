      PID    PPID    PGID     WINPID   TTY         UID    STIME COMMAND
      838       1     838      42776  cons2     197613 10:41:29 /usr/bin/bash
      689       1     689      54424  cons0     197613   Dec  7 /usr/bin/bash
      897     838     897      35340  cons2     197613 18:13:23 /usr/bin/PS
      734       1     734       7856  cons1     197613   Dec  7 /usr/bin/bash
